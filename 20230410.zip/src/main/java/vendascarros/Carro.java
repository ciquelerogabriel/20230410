package vendascarros;

public class Carro {


	//atributos carro
	private String marcaCarro;
	private String modeloCarro;
	private int anoCarro;
	private String placaCarro;
	private String chassiCarro;
	private double valorCarro;
	private String dataCarro;
	private String garantiaCarro;


	//construtor
	public Carro() {
	

		this.dataCarro = "00/00/0000";
		this.marcaCarro = "";
		this.modeloCarro = "";
		this.anoCarro = 0000;
		this.placaCarro = "";
		this.chassiCarro = "";
		this.valorCarro = 0;
		this.garantiaCarro = "";
	}


	//metodo
	


	public String getMarcaCarro () {
		return this.marcaCarro;
	}
	public void setMarcaCarro (String marca) {
		this.marcaCarro = marca;
	}



	public String getModeloCarro () {
		return this.modeloCarro;
	}
	public void setModeloCarro (String modelo) {
		this.modeloCarro = modelo;
	}



	public int getAnoCarro () {
		return this.anoCarro;
	}
	public void setAnoCarro (int ano) {
		this.anoCarro = ano;
	}



	public String getPlacaCarro () {
		return this.placaCarro;
	}
	public void setPlacaCarro (String placa) {
		this.placaCarro = placa;
	}



	public String getChassiCarro () {
		return this.chassiCarro;
	}
	public void setChassiCarro (String chassi) {
		this.chassiCarro = chassi;
	}
	
	
	
	public double getValorCarro () {
		return this.valorCarro;
	}
	public void setValorCarro (double valor) {
		this.valorCarro = valor;
	}



	public String getDataCarro () {
		return this.dataCarro;
	}
	public void setDataCarro (String data) {
		this.dataCarro = data;
	}



	public String getGarantiaCarro () {
		return this.garantiaCarro;
	}
	public void setGarantiaCarro (String garantia) {
		this.garantiaCarro = garantia;
	}
}
