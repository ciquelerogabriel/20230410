package vendascarros;

public class Cliente {
	//atributos cliente
		private String nomeComprador;
		private String cpfComprador;
		private String contatoComprador;




		//construtor
		public Cliente() {
			this.nomeComprador = "";
			this.cpfComprador = "000.000.000-00";
			this.contatoComprador = "+55";

		}


		//metodo
		public String getNomeComprador () {
			return this.nomeComprador;
		}
		public boolean setNomeComprador (String nome) {
			boolean valido = false;
			if (nome.matches("[a-zA-Z]+") && (nome.length() > 5)) {
				this.nomeComprador = nome;
				valido = true;
			}else {
				this.nomeComprador = "Anônimo";
			}
			return valido;
		}



		public String getCpfComprador () {
			return this.cpfComprador;
		}
		public boolean setCpfComprador (String cpf) {
			boolean valido = false;
			if (cpf.length() == 11) {
				this.cpfComprador = cpf;
				valido = true;
			}else {
				this.cpfComprador = "Inválido";
			}
			return valido;
		}



		public String getContatoComprador () {
			return this.contatoComprador;
		}
		public boolean setContatoComprador (String contato) {
			boolean valido = false;
			if (contato.length() == 14) {
				this.contatoComprador = contato;
				valido = true;
			}else {
				this.contatoComprador = "Inválido";
			}
			return valido;
		}



		
}
