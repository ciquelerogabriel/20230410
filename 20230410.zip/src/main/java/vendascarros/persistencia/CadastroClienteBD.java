package vendascarros.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;

import vendascarros.Cliente;

public class CadastroClienteBD {

	public boolean inserir(Cliente cli) throws Exception {
		boolean retorno = false;
		//comentario
		PreparedStatement stmt = null;
		Connection con = null;
		String sql = "INSERT INTO public.cliente(nome, cpf, contato)VALUES (?, ?, ?)";

		try {
			con = UtilJDBC.getConnection();
			stmt = con.prepareStatement(sql);
			stmt.setString(1, cli.getNomeComprador());
			stmt.setString(2, cli.getCpfComprador());
			stmt.setString(3, cli.getContatoComprador());
			
			stmt.executeUpdate();
			retorno = true;
		} catch (Exception e ) {
			System.out.println(e);
		} finally {
			if (stmt != null) { 
				stmt.close(); 
			}
			if (con != null) { 
				con.close();
			}
		}
		return retorno; }

}
