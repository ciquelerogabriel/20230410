package vendascarros.persistencia;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

import vendascarros.Carro;

public class CadVendaBD {
	public boolean inserir(Carro c) throws Exception {
		boolean retorno = false;
		//comentario
		PreparedStatement stmt = null;
		Connection con = null;
		String sql = "INSERT INTO vendacarro( marca, modelo, ano, placa, chassi, valor, data, garantia, idcliente)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			con = UtilJDBC.getConnection();
			stmt = con.prepareStatement(sql);
			stmt.setString(1, c.getMarcaCarro());
			stmt.setString(2, c.getModeloCarro());
			stmt.setInt(3, c.getAnoCarro());
			stmt.setString(4, c.getPlacaCarro());
			stmt.setString(5, c.getChassiCarro());
			stmt.setString(6, String.valueOf(c.getValorCarro()));
			stmt.setDate(7, Date.valueOf(c.getDataCarro()));
			stmt.setString(8, c.getGarantiaCarro());
			stmt.setInt(9, 1);
			
			stmt.executeUpdate();
			retorno = true;
		} catch (Exception e ) {
			System.out.println(e);
		} finally {
			if (stmt != null) { 
				stmt.close(); 
			}
			if (con != null) { 
				con.close();
			}
		}
		return retorno; }
}
