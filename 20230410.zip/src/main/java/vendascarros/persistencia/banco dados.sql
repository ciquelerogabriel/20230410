

--TABELA COM INFORMAÇÕES DO CLIENTE
CREATE TABLE Cliente (
id SERIAL not null,
nome varchar(100) not null,
cpf varchar(14) not null,
contato varchar(21) not null);

ALTER TABLE cliente ADD PRIMARY KEY (id);



--TABELA COM INFORMAÇÕES DE VENDA
CREATE TABLE VendaCarro (
id SERIAL not null,
idCliente integer not null,
marca varchar(100) not null,
modelo varchar(100) not null,
ano varchar(4) not null,
placa varchar(8) not null,
chassi varchar(17) not null,
valor varchar(25) not null,
data varchar(8) not null,
garantia varchar(3) not null);


ALTER TABLE VendaCarro ADD CONSTRAINT fk_cliente FOREIGN KEY (idCliente) REFERENCES Cliente (id);